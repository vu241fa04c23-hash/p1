from flask import Flask,jsonify,request,g
from pymongo import MongoClient
from bcrypt import hashpw,gensalt,checkpw
import jwt
import time
from functools import wraps

app=Flask(__name__)
client=MongoClient('mongodb+srv://vvu241fa04b89_db_user:triveni@cluster0.jntncje.mongodb.net/?appName=Cluster0')
db=client["jwt"]
users_collection=db["users"]
app.config["SECRET_KEY"]="iamtriveni"

def require_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Missing or invalid authorization header"}), 401
        
        token = auth_header.split(" ")[1]
        
        claims = jwt.decode(token,app.config["SECRET_KEY"],algorithms="HS256")
        g.user_claims=claims
        return f(*args, **kwargs)
        
    return decorated_function

@app.route('/signup',methods=["POST"])
def signup():
    data=request.get_json();
    #user=data.get("email")
    #users_collection.find_one({"email":user})
    #if user:
     #   return "Already registered"

    hashed_pass=hashpw(data.get("password").encode('utf-8'),gensalt())
    new_user={
        "name":data.get("name"),
        "email":data.get("email"),
        "password":hashed_pass
    }
    users_collection.insert_one(new_user)
    return "user inserted successfully"

@app.route("/login",methods=['POST'])
def login():
    data =request.get_json()
    email=data.get("email")
    password=data.get("password")
    user=users_collection.find_one({"email":email})
    if not user:
        return jsonify({"message":"Invalid user"})
    matched_pass=checkpw(password.encode('utf-8'),user["password"])
    if not matched_pass:
        return jsonify({"message":"Invalid password"})
    payload={
        "name":user["name"],
        "email":"email",
        "role":"user",
        "exp":int(time.time())+360000
    }
    token=jwt.encode(
        payload,
        app.config["SECRET_KEY"],
        algorithm="HS256"
    )
    return jsonify({
        "message":"login successful",
        "token":token
    })


@app.route("/")
def home():
    return "Welcome home"

@app.route("/profile")
@require_auth
def profile():
    return "Welcome to profile"

@app.route("/chat")
@require_auth
def chat():
    return "Welcome to chat"

if __name__ == "__main__":
    app.run(debug=True)