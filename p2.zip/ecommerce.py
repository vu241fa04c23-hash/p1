from flask import Flask,request,jsonify
from pymongo import MongoClient
                         
app = Flask(__name__)

#users=[]('mongodb+srv://vu241fa04c23_db_user:tejadivya@cluster0.auvh9ga.mongodb.net/')
client=MongoClient()
db=client["users-crt"]

user_collection=db["users"]
product_collection=db["products"]

print("DB connected")

@app.route('/')
def home():
    return "Hello Welcome To Flask.db connected "


# ====================================
# USERS
# ====================================

@app.route('/users', methods=['GET'])
def get_users():
    users = []
    users_list = user_collection.find()

    for user in users_list:
        user["_id"] = str(user["_id"])
        users.append(user)

    return jsonify(users)


@app.route('/users',methods=['POST'])
def add_users():
    data=request.get_json()

    user={
        "name":data.get("name"),
        "email":data.get("email")
    }

    user_collection.insert_one(user)

    return jsonify({"message":"user inserted sucessfully"})


# ====================================
# PRODUCTS
# ====================================

@app.route('/products', methods=['GET'])
def get_products():
    products = []
    products_list = product_collection.find()

    for product in products_list:
        product["_id"] = str(product["_id"])
        products.append(product)

    return jsonify(products)


@app.route('/products',methods=['POST'])
def add_products():
    data=request.get_json()

    product={
        "name":data.get("name"),
        "price":data.get("price"),
        "quantity":data.get("quantity")
    }

    product_collection.insert_one(product)

    return jsonify({"message":"product inserted sucessfully"})


@app.route('/products/<id>',methods=['GET'])
def get_product_byID(id):

    products_list = product_collection.find()

    for product in products_list:

        if str(product["_id"]) == id:

            product["_id"] = str(product["_id"])

            return jsonify(product)

    return jsonify({"message":"Product not found"})


@app.route('/products/<id>',methods=['DELETE'])
def delete_product_byID(id):

    products_list = product_collection.find()

    for product in products_list:

        if str(product["_id"]) == id:

            product_collection.delete_one({"_id": product["_id"]})

            return jsonify({"message":"Product Deleted Successfully"})

    return jsonify({"message":"Product not found"})


@app.route('/products/<id>',methods=['PUT'])
def update_product(id):

    data=request.get_json()

    products_list = product_collection.find()

    for product in products_list:

        if str(product["_id"]) == id:

            product_collection.update_one(
                {"_id": product["_id"]},
                {
                    "$set":{
                        "name":data.get("name"),
                        "price":data.get("price"),
                        "quantity":data.get("quantity")
                    }
                }
            )

            return jsonify({"message":"Product Updated Successfully"})

    return jsonify({"message":"Product not found"})


@app.errorhandler(404)
def unavailable_page(error):
    return jsonify({"message":"sorry page is not available"})


if __name__ == "__main__":
    app.run(debug=True)